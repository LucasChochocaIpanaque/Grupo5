const express = require('express');
const Usuario_model = require('../models/usuario_model');//MODELO DEFINIDO
const route = express.Router(); 
//Get, post, put, delete METODOS HTTP

//METODOS HTTP [REST(Json) SOA[xml]]
//             req- PETICION res- RESPUESTA
route.get('/usuarios', (req, res) => {
    Usuario_model
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
route.post('/usuario', (req, res) => {
    const usuario = Usuario_model(req.body);
    usuario
    .save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
route.get('/usuario/:id', (req, res) => {
    const {id} = req.params;
    Usuario_model
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
route.get('/usuarioByUser/:user', (req, res) => {
    const {user} = req.params;
    Usuario_model
    .findOne({usuario: user})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});
/************************************************/
route.get('/usuarioOK/', (req, res) => {
    const {usuario, contraseña} = Usuario_model(req.body);
    Usuario_model
    .findOne({usuario: usuario, contraseña: contraseña})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
route.get('/usuario/:usuario', (req, res) => {
    const {usuario} = req.params;
    Usuario_model
    .findOne({usuario:usuario})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});
/*
route.get();
route.post();
route.put();
route.delete();*/

module.exports = route;
