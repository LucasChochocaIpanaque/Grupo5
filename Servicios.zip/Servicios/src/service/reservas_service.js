const express = require('express');
const Reserva_model = require('../models/reserva_models');//MODELO DEFINIDO
const route = express.Router(); 
//Get, post, put, delete METODOS HTTP

//METODOS HTTP [REST(Json) SOA[xml]]
//             req- PETICION res- RESPUESTA
route.get('/reservas', (req, res) => {
    Reserva_model
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
route.post('/reserva', (req, res) => {
    const reserva = Reserva_model(req.body);
    reserva
    .save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
route.get('/reserva/:id', (req, res) => {
    const {id} = req.params;
    Reserva_model
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
route.get('/reservaByCod/:cod', (req, res) => {
    const {cod} = req.params;
    Reserva_model
    .findOne({cod_Programa: cod})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/*
route.get();
route.post();
route.put();
route.delete();*/

module.exports = route;