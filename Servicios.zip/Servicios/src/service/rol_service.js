const express = require('express');
const rol_model = require('../models/rol_model');//MODELO DEFINIDO
const route = express.Router(); 
//Get, post, put, delete METODOS HTTP

//METODOS HTTP [REST(Json) SOA[xml]]
//             req- PETICION res- RESPUESTA

/************************************************/
//OBTENER ROLES
route.get('/roles', (req, res) => {
    rol_model
    .find()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
//CREAR ROLES
route.post('/rol', (req, res) => {
    const rol = rol_model(req.body);
    rol
    .save()
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
//RECUPERAR ROL POR ID
route.get('/rol/:id', (req, res) => {
    const {id} = req.params;
    rol_model
    .findById(id)
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
//ACTUALIZAR ROL POR ID
route.get('/rol/:codRol', (req, res) => {
    const {codRol} = req.params;
    const {nombre} = req.body;
    rol_model
    .updateOne({cod: codRol}, {$set:{nombre}})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});

/************************************************/
//ELIMINAR ROL POR ID
route.get('/rol/:idRol', (req, res) => {
    const {idRol} = req.params;
    rol_model
    .deleteOne({cod: idRol})
    .then((data)=> res.json(data))
    .catch((error)=> res.json({message:error}));
});
/*
route.get();
route.post();
route.put();
route.delete();*/

module.exports = route;
