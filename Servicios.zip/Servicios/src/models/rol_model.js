const mongoose = require('mongoose');

const rol_model = mongoose.Schema({ //SE DEFINE COMO SERA EL ROL
    nombre: {
        type: String,
        required: true
    },
    cod: {
        type: String,
        required: true
    }

});

module.exports = mongoose.model('rol', rol_model); //AQUI SE TRANSFORMA EN UN MODELO GRACIAS A MONGOOSE