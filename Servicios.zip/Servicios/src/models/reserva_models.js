const mongoose = require('mongoose');

const Reserva_model = mongoose.Schema({ //SE DEFINE COMO SERA EL ROL

    cod_Programa: {
        type: String,
        required: true
    },
    tip_Habitacion: {
        type: String,
        required: true
    },
    nombr_Usuario: {
        type: String,
        required: true
    },
    dni: {
        type: Number,
        required: true
    },
    fech_Entrada: {
        type: String,
        required: true
    },
    fech_Salida: {
        type: String,
        required: true
    },
    correo_Usuario: {
        type: String,
        required: true
    }

});

module.exports = mongoose.model('reserva', Reserva_model); //AQUI SE TRANSFORMA EN UN MODELO GRACIAS A MONGOOSE