const mongoose = require('mongoose');

const Usuario_model = mongoose.Schema({ //SE DEFINE COMO SERA EL ROL

    cod: {
        type: String,
        required: true
    },
    nombres: {
        type: String,
        required: true
    },
    correo: {
        type: String,
        required: true
    },
    dni: {
        type: Number,
        required: true
    },
    telefono: {
        type: Number,
        required: true
    },
    usuario: {
        type: String,
        required: true
    },
    contraseña: {
        type: String,
        required: true
    },
    id_rol: {
        type: String,
        required: true
    }
    

});

module.exports = mongoose.model('usuario', Usuario_model); //AQUI SE TRANSFORMA EN UN MODELO GRACIAS A MONGOOSE